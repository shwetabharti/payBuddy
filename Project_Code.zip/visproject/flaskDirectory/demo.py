import plotly as py
from plotly.graph_objs import Bar, Layout
import pandas as pd
import numpy as np
df = pd.read_csv('loc.csv')
print(df['City'].values.tolist())
py.offline.plot({
"data": [
    Bar(x=df['City'].values.tolist(), y=df['compensation'].values.tolist(),marker = dict(color = 'orange'))
],
"layout": Layout(
bargap=0.1,
bargroupgap=0.2,
    title="Amazon's Salary Across Locations"
)
})